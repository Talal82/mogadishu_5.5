

<footer class="footer text-right">
	Website Design and Developed by <a href="https://www.tornado.ae" target="_blank">Tornado Computers Trading LLC. Dubai</a> <strong>Copyright &copy; 2018 <a href="<?php echo e(route('home')); ?>" target="_blank"> Mogadishu Adult Education Association - MAEA </a>.</strong> All rights reserved.
</footer>
