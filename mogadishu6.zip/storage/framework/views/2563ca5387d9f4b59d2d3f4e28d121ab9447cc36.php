Top Bar Start -->
<div class="topbar">

    <!-- LOGO -->
    <div class="topbar-left">
        <a href="<?php echo e(route('home')); ?>" class="logo"><span><?php echo e(config('app.name')); ?></span><i class="mdi mdi-layers"></i></a>
    </div>

    <!-- Button mobile view to collapse sidebar menu -->
    <div class="navbar navbar-default" role="navigation">
        <div class="container-fluid">

            <!-- Page title -->
            <ul class="nav navbar-nav list-inline navbar-left" style="width: 100%;">
                <li class="list-inline-item">
                    <button class="button-menu-mobile open-left">
                        <i class="mdi mdi-menu"></i>
                    </button>
                </li>
                <li class="list-inline-item"">
                    <h4 class="page-title" style="display: inline;"><?php echo $__env->yieldContent('page-title'); ?></h4>


                    <ol class="breadcrumb pull-right m-t-15">
                        
                        
                        <?php $__currentLoopData = $breadCrumb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if( $crumb['link'] != ''): ?>
                                <li class="breadcrumb-item"><a href="<?php echo e($crumb['link']); ?>"><?php echo e($crumb['text']); ?></a></li>
                            <?php else: ?>
                                <li class="breadcrumb-item active"><?php echo e($crumb['text']); ?></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>

                </li>
            </ul>
        </div><!-- end container -->
    </div><!-- end navbar -->
</div><!-- Top Bar End