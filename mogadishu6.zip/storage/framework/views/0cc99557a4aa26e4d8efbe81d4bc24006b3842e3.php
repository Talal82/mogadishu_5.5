<!DOCTYPE html>
<html>
    <head>
        
        <?php echo $__env->make('partials._head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>


    <body class="fixed-left">
        <?php echo Toastr::render(); ?>

        <!-- Begin page -->
        <div id="wrapper">
            
            <?php echo $__env->make('partials._header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            
            <?php echo $__env->make('partials._sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">
                                                
                        <!-- error of success messages -->
                        <?php echo $__env->make('partials._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        <!-- content body -->
                        <?php echo $__env->yieldContent('content'); ?>
                        <!-- content body -->
                            
                    </div> <!-- container -->
                </div> <!-- content -->

                
                <?php echo $__env->make('partials._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </div>


            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->
            

        </div>
        <!-- END wrapper -->

        
        <?php echo $__env->make('partials._scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </body>
</html>