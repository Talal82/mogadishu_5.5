<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('page-title', 'Users'); ?>

<?php $__env->startSection('stylesheets'); ?>


<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/plugins/datatables/buttons.bootstrap4.min.css')); ?>">

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/plugins/datatables/select.bootstrap4.min.css')); ?>">


<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/plugins/sweet-alert/sweetalert2.min.css')); ?>">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <h4 style="display: inline-block;">All Users</h4>
        <a class="btn btn-primary pull-right" href="<?php echo e(route('users.create')); ?>"><i class="fa fa-plus"></i> New</a>
      </div>
      <div class="card-body">
        <?php if(count($users) > 0): ?>
        <table class="table">
          <thead>
           <tr>
            
            <th>Sr.</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th class="text-center">Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <tr>
            
            <td><?php echo e(++$key); ?></td>
            <td><?php echo e($user -> full_name); ?></td>
            <td><?php echo e($user -> email); ?></td>
            <td><?php echo e($user -> phone); ?></td>
            <td class="text-center">
             <?php if($user -> status == true): ?>
             <a href="<?php echo e(route('users.status', [$user -> id])); ?>" class="btn btn-success btn-sm waves waves-effect">Active</a>
             <?php else: ?>
             <a href="<?php echo e(route('users.status', [$user -> id])); ?>" class="btn btn-danger btn-sm waves waves-effect">Blocked</a>
             <?php endif; ?>
           </td>
           <td>

            <a href="<?php echo e(route('users.show', [$user -> id])); ?>" class="btn btn-info btn-sm pull-left m-r-5 waves waves-effect" title="View"><i class="fa fa-eye" title="View"></i> View</a>

            <a href="<?php echo e(route('users.edit', [$user -> id])); ?>" class="btn btn-primary btn-sm pull-left m-r-5 waves waves-effect" title="Edit"><i class="fa fa-wrench" title="Edit"> Update</i></a>

            
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <?php else: ?>
    <div class="text-center">
      <p>You don't have any users yet.</p>
    </div>
    <?php endif; ?>
  </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<!-- Required datatable js -->
<script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<!-- Responsive examples -->
<script src="<?php echo e(asset('assets/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables/dataTables.select.min.js')); ?>"></script>

<script>
  var table = $('.table').DataTable({
    "ordering": true, 
    "sort": true,
    order: [[ 1, 'asc' ]]
  });
</script>

<script type="text/javascript" src="<?php echo e(asset('assets/plugins/sweet-alert/sweetalert2.min.js')); ?>"></script>
<script>
 $('.sa-remove').click(function (e) {
  e.preventDefault();
  swal({
    title: "Are you sure ??",
    text: 'The user will be deleted permanently.', 
    icon: "warning",
    buttons: true,
    showCancelButton: true,
    confirmButtonColor: '#d33',
    dangerMode: true,
  })
  .then((willDelete) => {
    if (willDelete) {
      // $(this).closest("form").submit();
      $('#form').submit();
    }
  }); 
});

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>