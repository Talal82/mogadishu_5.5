<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
            	<div class="pull-left">
            		<h4>User Profile</h4>
            	</div>
            	<div class="pull-right">
            		<a class="btn btn-primary" href="<?php echo e(route('profile.edit', [Auth::user() -> id])); ?>"> Update Profile</a>
            	</div>
            </div>
            <div class="card-body">
               <div class="row">
               		<div class="col-xs-12 col-sm-12 col-md-4 p-5 text-center">
                        <img src="<?php echo e(asset('uploads/avatars/'.Auth::user() -> image)); ?>" alt="User Image" height="200" width="200">
                        <h2><?php echo e(Auth::user() -> full_name); ?></h2>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-8 p-5">
                        <strong>Email: </strong><p><?php echo e(Auth::user() -> email); ?></p> 
                        <strong>Gender: </strong><p><?php echo e(ucwords(Auth::user() -> gender)); ?></p>
                        <strong>Phone No.: </strong><p><?php echo e(Auth::user() -> phone); ?></p>
                        <strong>Address: </strong><p><?php echo e(Auth::user() -> address); ?></p>
                        
                    </div>
               </div>
           </div>
       </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>