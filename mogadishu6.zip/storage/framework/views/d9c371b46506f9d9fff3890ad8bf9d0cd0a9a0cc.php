<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
	@media  print
	{
		* {-webkit-print-color-adjust:exact;}
		.display-none{
			display: none;
		}
	}
</style>

</head>
<body>
	this is the print page

	<a href="#" class="display-none" id="print">print</a>

	<a href="<?php echo e(URL::previous()); ?>" class="display-none">back</a>


	<script
	src="https://code.jquery.com/jquery-3.3.1.min.js"
	integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
	crossorigin="anonymous"></script>
	<script type="text/javascript">
		$('#print').on('click', function(e){
			e.preventDefault();
			window.print();
		});
	</script>
</body>
</html>