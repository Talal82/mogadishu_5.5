<?php $__env->startSection('title', 'Reset Password'); ?>

<?php $__env->startSection('content'); ?>

            <div class="m-t-40 card-box">
                <div class="text-center">
                    <h4 class="text-uppercase font-bold m-b-0">Reset Password</h4>

                </div>
                <div class="p-20">
                    <form class="form-horizontal m-t-20" action="<?php echo e(route('password.request')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="token" value="<?php echo e($token); ?>">
                        <div class="form-group">
                            <div class="col-xs-12">
                                <input id="email" name="email" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" type="email" required="" placeholder="Enter email">
                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-12">
                                <input id="password" name="password" class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" type="password" required="" placeholder="Enter password">
                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-12">
                                <input id="password_confirmation" name="password_confirmation" class="form-control" type="password" required="" placeholder="Confirm Password">
                            </div>
                        </div>

                        <div class="form-group text-center m-t-20 m-b-0">
                            <div class="col-xs-12">
                                <button class="btn btn-custom btn-bordred btn-block waves-effect waves-light" type="submit">Send Email</button>
                            </div>
                        </div>

                    </form>

                </div>
            </div>
            <!-- end card-box -->

            <div class="row">
                <div class="col-sm-12 text-center">
                    <p class="text-muted">Already have account?<a href="<?php echo e(route('login')); ?>" class="text-primary m-l-5"><b>Sign In</b></a></p>
                </div>
            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.middle_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>