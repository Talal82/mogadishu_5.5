<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('page-title', 'Edit User'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header">
				<div class="pull-left">
					<h2>Edit New User</h2>
				</div>
				<div class="pull-right">
					<a class="btn btn-primary" href="<?php echo e(route('users.index')); ?>"> Back</a>
				</div>
			</div>
			<div class="card-body">
				<?php echo Form::model($user, ['method' => 'PATCH','route' => ['users.update', $user->id]]); ?>

				<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-6">
						<div class="form-group">
							<label for="full_name">Full Name:</label>
							<?php echo Form::text('full_name', null, array('placeholder' => 'John Doe','class' => 'form-control')); ?>

						</div>
					</div>

					<div class="col-xs-12 col-sm-12 col-md-6">
						<div class="form-group">
							<label for="">Email:</label>
							<?php echo Form::text('email', null, array('placeholder' => 'example@gmail.com','class' => 'form-control')); ?>

						</div>
					</div>

					<div class="col-xs-12 col-sm-12 col-md-6">
						<div class="form-group">
							<label for="">Phone:</label>
							<?php echo Form::text('phone', null, array('placeholder' => 'Phone Number','class' => 'form-control')); ?>

						</div>
					</div>
					<div class="col-xs-12 col-sm-12 col-md-6">
						<div class="form-group">
							<strong>Address:</strong>
							<?php echo Form::text('address', null, array('placeholder' => 'address','class' => 'form-control')); ?>

						</div>
					</div>
					<div class="col-xs-12 col-sm-12 col-md-6">
						<div class="form-group">
							<strong>Password:</strong>
							<?php echo Form::password('password', array('placeholder' => 'Password','class' => 'form-control')); ?>

						</div>
					</div>
					<div class="col-xs-12 col-sm-12 col-md-6">
						<div class="form-group">
							<strong>Confirm Password:</strong>
							<?php echo Form::password('confirm-password', array('placeholder' => 'Confirm Password','class' => 'form-control')); ?>

						</div>
					</div>

					<div class="col-xs-12 col-sm-12 col-md-6">
						<div class="form-group">
							<label for="">Gender:</label>
							<select name="gender" class="form-control">
								<?php if(strtolower($user -> gender) == 'male'): ?>
								<option value="Male" selected>Male</option>
								<option value="Female">Female</option>
								<?php else: ?>
								<option value="Male">Male</option>
								<option value="Female" selected>Female</option>
								<?php endif; ?>
							</select>
						</div>
					</div>

					<div class="col-xs-12 col-sm-12 col-md-12">
						<button type="submit" class="btn btn-primary btn-block">Edit User</button>
					</div>
				</div>
				<?php echo Form::close(); ?>

			</div>
		</div>

	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>