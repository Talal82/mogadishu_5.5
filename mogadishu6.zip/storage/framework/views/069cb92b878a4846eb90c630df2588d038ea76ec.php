<!--========== Left Sidebar Start ========== -->
<div class="left side-menu">
    <div class="sidebar-inner slimscrollleft">

        <!-- User -->
        <div class="user-box">
            <div class="user-img">
                <img src="<?php echo e(asset('uploads/avatars/'.Auth::user() -> image)); ?>" alt="user-img" title="<?php echo e(Auth::user() -> full_name); ?>" class="rounded-circle img-thumbnail img-responsive">
                <div class="user-status online"><i class="mdi mdi-adjust"></i></div>
            </div>
            <h5 style="margin-top: 15px;"><a href="<?php echo e(route('home')); ?>"><?php echo e(Auth::user() -> full_name); ?></a> </h5>
            <ul class="list-inline">
                

                <li class="list-inline-item">
                    <a href="#" class="text-custom" title="Logout" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                        <i class="mdi mdi-power"></i>
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                </li>
            </ul>
        </div>
        <!-- End User -->

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <ul>
                <li class="text-muted menu-title">Navigation</li>

                <li>
                    <a href="<?php echo e(route('home')); ?>" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Dashboard </span> </a>
                </li>

                <?php if(auth()->check() && auth()->user()->hasRole('superadmin')): ?>
                <li>
                    <a href="<?php echo e(route('users.index')); ?>" class="waves-effect"><i class="fa fa-user"></i> <span> User Management</span> </a>
                </li>
                <?php endif; ?>

                <?php if(auth()->check() && auth()->user()->hasRole('superadmin')): ?>
                <li>
                    <a href="<?php echo e(route('reports.all')); ?>" class="waves-effect"><i class="mdi mdi-texture"></i> <span> All Reports</span> </a>
                </li>
                <?php endif; ?>

                <li>
                    <a href="<?php echo e(route('reports.index')); ?>" class="waves-effect"><i class="mdi mdi-texture"></i> <span> My Reports</span> </a>
                </li>


                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-settings"></i> <span> Settings</span> <span class="menu-arrow"></span></a>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo e(route('account.index')); ?>">Account Settings</a></li>
                    </ul>
                </li>
            </ul>
            <div class="clearfix"></div>
        </div>
        <!-- Sidebar -->
        <div class="clearfix"></div>

    </div>

</div>
            <!-- Left Sidebar End