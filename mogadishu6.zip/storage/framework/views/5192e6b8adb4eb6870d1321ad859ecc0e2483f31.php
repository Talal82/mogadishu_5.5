<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>


<div class="m-t-40 card-box">
    <div class="text-center">
        <h4 class="text-uppercase font-bold m-b-0">Sign In</h4>
    </div>
    <div class="p-20">
        <form class="form-horizontal m-t-20" action="<?php echo e(route('login')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <div class="col-xs-12">
                    <input id="email" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" type="email" name="email" required autofocus placeholder="Email" value="<?php echo e(old('email')); ?>">
                    <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group">
                <div class="col-xs-12">
                    <input id="password" name="password" class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" type="password" required="" placeholder="Password">
                    <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group ">
                <div class="col-xs-12">
                    <div class="checkbox checkbox-custom">
                        <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                        <label for="remember">
                            Remember me
                        </label>
                    </div>

                </div>
            </div>

            <div class="form-group text-center m-t-30">
                <div class="col-xs-12">
                    <button class="btn btn-custom btn-bordred btn-block waves-effect waves-light" type="submit">Log In</button>
                </div>
            </div>

            <div class="form-group m-t-30 m-b-0">
                <div class="col-sm-12">
                    <a href="<?php echo e(route('password.request')); ?>" class="text-muted"><i class="fa fa-lock m-r-5"></i> Forgot your password?</a>
                </div>
            </div>
        </form>

    </div>
</div>
<!-- end card-box-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.middle_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>